<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class PaymentController extends Controller
{
    public function createPayment(Request $request)
    {
        $tranId = $request->input('tran_id'); // ID đơn hàng
        $amount = $request->input('amount');  // Tổng tiền

        $payload = [
            'merchant_id'  => env('ABA_MERCHANT_ID'),
            'tran_id'      => $tranId,
            'amount'       => $amount,
            'currency'     => 'USD',
            'order'        => 'Order #' . $tranId,
            'return_url'   => url('/payment-success'),
            'cancel_url'   => url('/payment-cancel'),
            'callback_url' => url('/payment-callback'),
        ];

        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
            'Accept'       => 'application/json',
            'X-Api-Key'    => env('ABA_API_KEY'),
        ])->post(env('ABA_API_URL'), $payload);

        // 📦 Ghi log để kiểm tra response ABA trả về gì
        Log::info('📦 ABA Response:', $response->json());

        if ($response->successful()) {
            $data = $response->json();

            // ✅ Bắt các key có thể chứa QR code
            $qrImage = $data['qr_code']
                    ?? $data['qr_url']
                    ?? $data['invoice_url']
                    ?? null;

            return response()->json([
                'success'   => $qrImage !== null,
                'qr_image'  => $qrImage,
                'message'   => $qrImage ? 'Success' : 'Không tìm thấy mã QR.'
            ]);
        } else {
            // ❌ Trường hợp lỗi từ phía ABA
            Log::error('❌ ABA Error:', [
                'status' => $response->status(),
                'body' => $response->body()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'ABA response error: ' . $response->body()
            ], $response->status());
        }
    }
}
